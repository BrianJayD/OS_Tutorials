#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	int integer_array[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

	// Print integers
	for (int i = 0; i < 10; ++i)
	{
		printf("%i\n", integer_array[i]);
	}

}
